%% regressione analizzando il PM10 su Casirate d'Adda
%%Caricamento dati
load('G08.mat');

%%Ispezione del dataset
summary(tG)

%%calcoli PM 10 Casirate d'Adda
data_PM10 = tG(:,{'PM10_tG1','Temperatura_tG1','Pioggia_cum_tG1','Umidita_relativa_tG1','NOx_tG1','O3_tG1','NO2_tG1'});
data_PM10.Properties.VariableNames = {'PM10','Temp','Pioggia','Umid','Ossidi','Ozono','Diossido di Azoto'};
M_PM10_caso1 = fitlm(data_PM10,'ResponseVar','PM10','PredictorVars',{'Temp','Pioggia','Umid','Ossidi','Ozono','Diossido di Azoto'})
%tolgo la variabile con pvalue più alto
M_PM10_caso2 = fitlm(data_PM10,'ResponseVar','PM10','PredictorVars',{'Temp','Pioggia','Ossidi','Ozono','Diossido di Azoto'})
M_PM10 = fitlm(data_PM10,'ResponseVar','PM10','PredictorVars',{'Pioggia','Ossidi','Ozono','Diossido di Azoto'})

%modello con pvalue tutti accettabili. Inoltre i 2 valori R-squared son simili,
%scegliamo dunque come modello migliore M_PM10

%%controllo adattabilità 
Ad_tG1_PM10 = M_PM10.Rsquared.Ordinary

%%analisi dei residui
res_tG1_PM10 = M_PM10.Residuals.Raw;
graf_tG1_PM10 = plot(res_tG1_PM10)
yline(0,'r','LineWidth',3);
yline(mean(res_tG1_PM10),'b','LineWidth',2);
title('analisi residui');
xlabel('n osservazioni');
ylabel('valore residuo');

histfit(res_tG1_PM10)   %i residui si distribuiscono attorno allo 0, corretto.
title('istogramma riferito all analisi dei residui su Casirate d Adda');

%%calcolo della covarianza
CoefficientCovariance_PM10 = M_PM10.CoefficientCovariance(2 : end, 1)
cov = table(CoefficientCovariance_PM10, 'RowNames',{'Pioggia','Ossidi','Ozono','Diossido di Azoto'})
cov.Properties.VariableNames={'PM10'}

%grafico
plot(M_PM10)
title('grafico regressione PM10 Casirate d Adda');


%% calcoli PM 10 Bergamo %%

dataBG1 = tG(:,{'PM10_BG','Temperatura_BG','Pioggia_cum_BG','Umidita_relativa_BG','NOx_BG','O3_BG','NO2_BG'});
dataBG1.Properties.VariableNames = {'PM10','Temp','Pioggia','Umid','Ossidi','Ozono','Diossido di Azoto'};
MPM10 =  fitlm(dataBG1,'ResponseVar','PM10','PredictorVars',{'Pioggia','Ossidi','Ozono','Diossido di Azoto'})

%correlazione valori PM10 bergamo e Casirate d'Adda
x=tG.PM10_BG
y=tG.PM10_tG1
corr(x,y)  
scatter(x,y)
title('correlazione PM10 Bg e tG1')
xlabel('BG')
ylabel('Casirate d Adda')
%possiamo dedurre che l'inquinamento dato da PM10 nelle 2 città è simile e
%si può descrivere con molta precisione usando l'uno o l'altro modello.

%%controllo adattabilità 
AdBG1 = MPM10.Rsquared.Ordinary

%%analisi dei residui 
resBG1 = MPM10.Residuals.Raw
grafBG1 = plot(resBG1)
yline(0,'r','LineWidth',3)
yline(mean(resBG1),'b','LineWidth',2)
title('analisi residui')
xlabel('n osservazioni')
ylabel('valore residuo')

histfit(resBG1)   %i residui si distribuiscono attorno allo 0, corretto.
title('istogramma riferito all analisi dei residui su Bergamo')

%%covarianze 
covarianze = MPM10.CoefficientCovariance(2:end,1)
covPM10 = table(covarianze, 'RowNames',{'Pioggia','Ossidi','Ozono','Diossido di Azoto'})
covPM10.Properties.VariableNames={'PM10'}

%%grafico 
plot1 = plot(MPM10)
title('GRAFICO REGRESSIONE PM10 BG')



